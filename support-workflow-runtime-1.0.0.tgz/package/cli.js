#!/usr/bin/env node
'use strict';
const runtime = require('./index.js');
console.log(runtime.ready());
